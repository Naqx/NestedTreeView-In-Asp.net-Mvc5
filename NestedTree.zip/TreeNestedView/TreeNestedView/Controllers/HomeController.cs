﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TreeNestedView.Models;

namespace TreeNestedView.Controllers
{
    public class HomeController : Controller
    {
        private readonly NestedTreeDBEntities db = new NestedTreeDBEntities();
        public ActionResult Index()
        {
            List<Employee> list = new List<Employee>();
            list = db.Employees.OrderBy(a => a.AccountID).ToList();
            return View(list);
        }

        [HttpGet]
        public ActionResult Create()
        {
            DropdownId();
            return View();
        }
        [HttpPost]
        public ActionResult Create(Employee tb)
        {
            tb.CreatedDate = DateTime.Now;
            db.Employees.Add(tb);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        private void DropdownId()
        {
            List<SelectListItem> emp = new SelectList(db.Employees, "AccountID", "Title").ToList();
            ViewBag.DropDownEmp = emp;
        }
    }
}